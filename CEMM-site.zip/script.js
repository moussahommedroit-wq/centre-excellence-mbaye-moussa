function changerMode(){
  document.body.classList.toggle("dark");
  localStorage.setItem(
    "mode",
    document.body.classList.contains("dark") ? "dark" : "clair"
  );
}

if(localStorage.getItem("mode")==="dark"){
  document.body.classList.add("dark");
}

function messageRessource(){
  alert("Cette ressource sera bientôt ajoutée.");
}

document.getElementById("formulaire").addEventListener("submit",function(e){
  e.preventDefault();

  const nom=encodeURIComponent(document.getElementById("nom").value);
  const tel=encodeURIComponent(document.getElementById("telephone").value);
  const statut=encodeURIComponent(document.getElementById("statut").value);
  const msg=encodeURIComponent(document.getElementById("message").value);

  const texte=
    "Bonjour Monsieur Moussa,%0A%0A"+
    "Préinscription Terminale D%0A"+
    "Nom : "+nom+"%0A"+
    "Téléphone : "+tel+"%0A"+
    "Situation : "+statut+"%0A"+
    "Message : "+msg;

  window.open(
    "https://wa.me/2250777774033?text="+texte,
    "_blank"
  );
});

function afficherDashboard(){
  document.getElementById("loginPanel").classList.add("hidden");
  document.getElementById("dashboard").classList.remove("hidden");
}

function afficherConnexion(){
  document.getElementById("loginPanel").classList.remove("hidden");
  document.getElementById("dashboard").classList.add("hidden");
}

document.getElementById("loginForm").addEventListener("submit",function(e){
  e.preventDefault();

  const id=document.getElementById("identifiant").value.trim();
  const pass=document.getElementById("motdepasse").value;

  if(id==="eleve" && pass==="cemm2027"){
    localStorage.setItem("cemmConnecte","oui");
    document.getElementById("loginError").textContent="";
    afficherDashboard();
  }else{
    document.getElementById("loginError").textContent=
      "Identifiant ou mot de passe incorrect.";
  }
});

function deconnexion(){
  localStorage.removeItem("cemmConnecte");
  afficherConnexion();
}

if(localStorage.getItem("cemmConnecte")==="oui"){
  afficherDashboard();
}
